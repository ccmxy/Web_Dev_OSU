
var express = require('express');
var mysql = require('./dbcon.js');
var path = require('path');

var app = express();
var handlebars = require('express-handlebars').create({defaultLayout:'main'});
app.engine('handlebars', handlebars.engine);
app.set('view engine', 'handlebars');
var Handlebars = require('express-handlebars');

app.set('port', 3002);
app.use(express.static(path.join(__dirname, 'public')));
bodyParser = require('body-parser');

app.use(bodyParser.urlencoded({
    extended: false
}));
app.use(bodyParser.json());

/**** Original Render ****/
app.get('/',function(req,res,next){
  var context = {};
  mysql.pool.query('SELECT * FROM workouts', function(err, rows, fields){
    if(err){
      next(err);
      return;
    }
    context.results = JSON.stringify(rows);
	
    workoutList = [];
    getList(workoutList, rows);
    context.workoutList = workoutList;
    res.render('home', context);
  });
});

app.post('/',function(req,res,next){

  var context = {};
 /************** NEW WORKOUT *********/
  if(req.body['New Workout']){
	  mysql.pool.query("INSERT INTO workouts (`name`,`reps`, `weight`, `date`, `lbs`) VALUES (?,?,?,?,?)", 
	  [req.body.name, req.body.reps, req.body.weight, req.body.date, req.body.lbs], function(err, result){
	    if(err){
	      next(err);
	      return;
	    }

   });
  } //End if new workout

/******** DELETE WORKOUT  ******/
  if(req.body['Delete Workout']){
	  mysql.pool.query("DELETE FROM  workouts WHERE id=?", 
	  [req.body.id], function(err, result){
	    if(err){
	      next(err);
	      return;
	    }    
  });
  } //End if delete workout

/***** UPDATE WORKOUT *****/
 if(req.body['Update Workout']){
	console.log("Save button pressed");
 	mysql.pool.query("UPDATE workouts SET name=?, reps=?, weight=?, date=?, lbs=? WHERE id=? ",
    	[req.body.name, req.body.reps, req.body.weight, req.body.date, req.body.lbs, req.body.id],
    	function(err, result){
    	if(err){
     	 next(err);
      	return;
    	}
  });
 }//End if update workout
	
 /************ RENDER PAGE **********/
   mysql.pool.query('SELECT * FROM workouts', function(err, rows, fields){
    if(err){
      next(err);
      return;
    }
    context.results = JSON.stringify(rows);
	workoutList = [];
	getList(workoutList, rows);
	context.workoutList = workoutList;
	res.render('home', context);
  });

});

/********* EDIT WORKOUT PAGE ****/
app.post('/edit-workout',function(req,res,next){
	context = {};
  context.id = req.body.id;
  context.name = req.body.name;
  context.reps = req.body.reps;
  context.weight = req.body.weight;
  context.date = req.body.date;
  context.lbs = req.body.lbs;

	res.render('edit',context);
});

/* Function to populate the list from JSON data */
function getList(list, jsonRows) {
	for(var row in jsonRows){

		var name, reps, weight, date, lbs;
		rowCount = 0;
		for(var r in jsonRows[row]){
		
			if (rowCount === 0){
				id = jsonRows[row][r]
		
			}
			if (rowCount === 1){
				 name =  jsonRows[row][r]
			}
			if (rowCount === 2) {
				 reps = jsonRows[row][r]
			}
			if (rowCount === 3) {
				weight = jsonRows[row][r]
			}
			if (rowCount === 4) {
				 date = jsonRows[row][r]
			}
			if (rowCount === 5){
				lbs = jsonRows[row][r]
				list.push({
					'id': id,
					'name': name,
					'reps': reps,
					'weight': weight,
					'date': date,
					'lbs': lbs
				});
			}
			rowCount++;
		}
	}

}

/**** RESET TABLE PAGE ****/
app.get('/reset-table',function(req,res,next){
  var context = {};
  mysql.pool.query("DROP TABLE IF EXISTS workouts", function(err){ //replace your connection pool with the your variable containing the connection pool
    var createString = "CREATE TABLE workouts("+
    "id INT PRIMARY KEY AUTO_INCREMENT,"+
    "name VARCHAR(255) NOT NULL,"+
    "reps INT,"+
    "weight INT,"+
    "date DATE,"+
    "lbs BOOLEAN)";
    mysql.pool.query(createString, function(err){
    res.render('home',context);
    })
  });
});

app.use(function(req,res){
  res.status(404);
  res.render('404');
});

app.use(function(err, req, res, next){
  console.error(err.stack);
  res.status(500);
  res.render('500');
});

app.listen(app.get('port'), function(){
  console.log('Express started on http://localhost:' + app.get('port') + '; press Ctrl-C to terminate.');
});

